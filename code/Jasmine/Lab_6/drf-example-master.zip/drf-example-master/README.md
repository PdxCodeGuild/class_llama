# drf-example

This repo comes with a model, sample data, a home page, and login/logout/sign-up functionality. It's ready for an API!

Admin credentials:

user: `admin`

pass: `test1234`
